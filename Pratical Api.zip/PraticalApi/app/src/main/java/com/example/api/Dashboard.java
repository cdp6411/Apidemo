package com.example.api;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public class Dashboard extends AppCompatActivity {
    RecyclerView recyclerview;

    private static final String URL_DATA = "https://www.iroidsolutions.com/interview/test.json";
    public DashboardAdapter dashboardAdapter;
    private LinearLayoutManager linearLayoutManager;
    private List<User> namelist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        namelist = new ArrayList<>();
        recyclerview = findViewById(R.id.recyclerview);
        recyclerview.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        recyclerview.setAdapter(dashboardAdapter);
        recyclerview.setHasFixedSize(true);


        dashboardAdapter = new DashboardAdapter(this, namelist, this);
        recyclerview.setHasFixedSize(true);
        linearLayoutManager = new LinearLayoutManager(this);
        recyclerview.setLayoutManager(linearLayoutManager);
        recyclerview.setAdapter(dashboardAdapter);


    }

    StringRequest stringRequest = new StringRequest(Request.Method.GET,
            URL_DATA, new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            GsonBuilder gsonBuilder = new GsonBuilder();
            Gson gson = gsonBuilder.serializeNulls().create();

          User user = gson.fromJson(response, User.class);
          user.getName();
          user.getPhone();
          user.getPicture();
          user.getEmail();

        }
    }, new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            Toast.makeText(Dashboard.this, "Fali", Toast.LENGTH_SHORT).show();
        }
    });
//         RequestQueue requestQueue = Volley.newRequestQueue(Dashboard.this);
        //requestQueue.add();
}
